const mongoose=require("mongoose")
const highlight = require("../models/highlight")
mongoose.connect("mongodb://localhost:27017/shopregistration").then(()=>{
          console.log("connection successful");
          // highlight.create([
          //           {
          //               imgurl:"/css/login.css",
          //               description:"guirrjgfviureghfivure",
          //               onclick:"www.google.com",
          //               title:"hiii"
          //           }
          // ])
}).catch((e)=>{
          console.log(e);
})